import { BasePage } from "./BasePage";
import {Locator } from "@playwright/test";

export class BooksPage extends BasePage {

    // ADD YOUR LOCATORS HERE...
    // public readonly elementName: Locator = this.page.locator("locator");
    
}