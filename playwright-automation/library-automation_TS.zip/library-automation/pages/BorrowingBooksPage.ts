import { BasePage } from "./BasePage";
import {Locator } from "@playwright/test";

export class BorrowingBooksPage extends BasePage {

    // ADD YOUR LOCATORS HERE...
    // public readonly elementName: Locator = this.page.locator("locator");

    
}