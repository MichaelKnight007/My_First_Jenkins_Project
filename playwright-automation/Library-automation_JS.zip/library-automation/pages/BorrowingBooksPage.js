import { BasePage } from "./BasePage.js";

export class BorrowingBooksPage extends BasePage {

  // ADD YOUR LOCATORS HERE...

}
