import { BasePage } from "./BasePage.js";

export class BooksPage extends BasePage {

  // ADD YOUR LOCATORS HERE...


}
