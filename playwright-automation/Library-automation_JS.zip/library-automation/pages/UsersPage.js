import { BasePage } from "./BasePage.js";

export class UsersPage extends BasePage {

  // ADD YOUR LOCATORS HERE...

  
}
